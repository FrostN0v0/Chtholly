from dataclasses import dataclass, field

from yarl import URL


class Config:
    @property
    def identity(self) -> str:
        raise NotImplementedError

    @property
    def token(self) -> str | None:
        raise NotImplementedError

    @property
    def api_base(self) -> URL:
        raise NotImplementedError


@dataclass
class WebsocketsInfo(Config):
    host: str = "localhost"
    port: int = 5140
    path: str = ""
    token: str | None = None
    secure: bool = False
    timeout: float | None = None
    identity: str = field(init=False, default=None)  # type: ignore
    api_base: URL = field(init=False, default=None)  # type: ignore

    def __post_init__(self):
        if self.path and not self.path.startswith("/"):
            self.path = f"/{self.path}"
        self.identity = f"{self.host}:{self.port}"
        self.api_base = URL(f"http{'s' if self.secure else ''}://{self.host}:{self.port}{self.path}") / "v1"

    @property
    def ws_base(self):
        return URL(f"ws{'s' if self.secure else ''}://{self.host}:{self.port}{self.path}") / "v1"


@dataclass
class WebhookInfo(Config):
    host: str = "127.0.0.1"
    port: int = 8080
    path: str = "v1/events"
    token: str | None = None
    secure: bool = False
    server_host: str = "localhost"
    server_port: int = 5140
    server_path: str = ""
    timeout: float | None = None
    identity: str = None  # type: ignore
    api_base: URL = None  # type: ignore

    def __post_init__(self):
        if self.path and not self.path.startswith("/"):
            self.path = f"/{self.path}"
        if self.server_path and not self.server_path.startswith("/"):
            self.server_path = f"/{self.server_path}"
        self.identity = f"{self.host}:{self.port}{self.path}"
        self.api_base = (
            URL(f"http{'s' if self.secure else ''}://{self.server_host}:{self.server_port}{self.server_path}") / "v1"
        )
