import asyncio
from collections.abc import Iterable

from arclet.letoderea import publish
from arclet.cithun import ResourceNode, Role, User
from arclet.cithun.async_ import AsyncStore
from arclet.cithun.model import AclEntry, Permission, Track, TrackLevel
from entari_plugin_database import get_session
from sqlalchemy.sql import select

from .event import UserSetTrackLevel
from .model import (
    AclEntryModel,
    RoleInheritsModel,
    RoleModel,
    TrackLevelModel,
    TrackModel,
    UserModel,
    UserRolesModel,
)


class ORMStore(AsyncStore):
    def __init__(self):
        self.loaded = asyncio.Event()
        self.resources: dict[str, ResourceNode] = {}
        self.users: dict[str, User] = {}
        self.roles: dict[str, Role] = {"group:default": Role("group:default", "Default")}
        self.acls: dict[int, AclEntry] = {}  # type: ignore
        self.tracks: dict[str, Track] = {}

    @property
    def default_role(self) -> Role:
        return self.roles["group:default"]

    async def create_user(self, uid: str, name: str) -> User:
        await self.loaded.wait()
        if uid in self.users:
            return self.users[uid]
        async with get_session() as session:
            async with session.begin():
                user_model = UserModel(id=uid, name=name)
                session.add(user_model)
            await session.refresh(user_model)
            user = user_model.dump()
        self.users[uid] = user
        await self.inherit(user, self.default_role)
        return user

    async def get_or_create_user(self, uid: str, name: str) -> User:
        await self.loaded.wait()
        if uid in self.users:
            return self.users[uid]
        return await self.create_user(uid, name)

    async def create_role(self, rid: str, name: str) -> Role:
        await self.loaded.wait()
        if rid in self.roles:
            return self.roles[rid]
        async with get_session() as session:
            async with session.begin():
                role_model = RoleModel(id=rid, name=name)
                session.add(role_model)
            await session.refresh(role_model)
        role = role_model.dump()
        self.roles[rid] = role
        return role

    async def get_role(self, rid: str) -> Role:
        if rid in self.roles:
            return self.roles[rid]
        if f"group:{rid}" in self.roles:
            return self.roles[f"group:{rid}"]
        role = next(
            (role for role in self.roles.values() if role.name == rid),
            None,
        )
        if role:
            return role
        raise KeyError(rid)

    async def create_track(self, tid: str, name: str | None = None) -> Track:
        await self.loaded.wait()
        if tid in self.tracks:
            return self.tracks[tid]
        async with get_session() as session:
            async with session.begin():
                track_model = TrackModel(id=tid, name=name or tid)
                session.add(track_model)
            await session.refresh(track_model)
            track = track_model.dump()
            self.tracks[tid] = track
            return track

    async def delete_track(self, tid: str) -> Track:
        await self.loaded.wait()
        if tid not in self.tracks:
            raise KeyError(tid)
        async with get_session() as session, session.begin() as _:
            track_model = await session.get(TrackModel, tid)
            if track_model:
                await session.delete(track_model)
        return self.tracks.pop(tid)

    async def _add_acl(self, acl: AclEntry):
        await self.loaded.wait()
        async with get_session() as session, session.begin() as _:
            target = await session.scalar(
                select(AclEntryModel)
                .where(AclEntryModel.subject_type == acl.subject_type)
                .where(AclEntryModel.subject_id == acl.subject_id)
                .where(AclEntryModel.resource_id == acl.resource_id)
            )
            if target:
                return
            acl_model = AclEntryModel(
                subject_type=acl.subject_type,
                subject_id=acl.subject_id,
                resource_id=acl.resource_id,
                allow_mask=int(acl.allow_mask),
                deny_mask=int(acl.deny_mask),
            )
            session.add(acl_model)
            await session.flush()
            acl_id = acl_model.id
        self.acls[acl_id] = acl

    async def get_primary_acl(
        self,
        subject: User | Role,
        resource_id: str,
    ) -> AclEntry | None:
        await self.loaded.wait()
        async with get_session() as session:
            target = await session.scalar(
                select(AclEntryModel)
                .where(AclEntryModel.subject_type == subject.type)
                .where(AclEntryModel.subject_id == subject.id)
                .where(AclEntryModel.resource_id == resource_id)
            )
            if target:
                return self.acls[target.id]

    async def get_acl(self, subject: User | Role, resource_id: str) -> AclEntry | None:
        await self.loaded.wait()
        async with get_session() as session:
            acl = (
                await session.scalars(
                    select(AclEntryModel)
                    .where(AclEntryModel.subject_type == subject.type)
                    .where(AclEntryModel.subject_id == subject.id)
                    .where(AclEntryModel.resource_id == resource_id)
                )
            ).one_or_none()
            if acl:
                return self.acls[acl.id]

    async def iter_acls_for_resource(self, resource_id: str) -> Iterable[AclEntry]:
        await self.loaded.wait()
        async with get_session() as session:
            acls = (await session.scalars(select(AclEntryModel).where(AclEntryModel.resource_id == resource_id))).all()
            return (self.acls[acl_model.id] for acl_model in acls)

    async def inherit(self, child: User | Role, parent: Role):
        await self.loaded.wait()
        if isinstance(child, Role):
            child_role = self._ensure_role(child)
            self._ensure_role(parent)
            if parent.id not in child_role.parent_role_ids:
                async with get_session() as session, session.begin() as _:
                    role_inherit_model = RoleInheritsModel(role_id=child_role.id, parent_role_id=parent.id)
                    await session.merge(role_inherit_model)
                child_role.parent_role_ids.append(parent.id)
        else:
            user = self._ensure_user(child)
            self._ensure_role(parent)
            if parent.id not in user.role_ids:
                async with get_session() as session, session.begin() as _:
                    user_roles_model = UserRolesModel(user_id=user.id, role_id=parent.id)
                    await session.merge(user_roles_model)
                user.role_ids.append(parent.id)

    async def cancel_inherit(self, child: User | Role, parent: Role):
        await self.loaded.wait()
        if isinstance(child, Role):
            child_role = self._ensure_role(child)
            self._ensure_role(parent)
            if parent.id in child_role.parent_role_ids:
                async with get_session() as session, session.begin() as _:
                    role_inherit_model = await session.get(RoleInheritsModel, (child_role.id, parent.id))
                    if role_inherit_model:
                        await session.delete(role_inherit_model)
                child_role.parent_role_ids.remove(parent.id)
        else:
            user = self._ensure_user(child)
            self._ensure_role(parent)
            if parent.id in user.role_ids:
                async with get_session() as session, session.begin() as _:
                    user_roles_model = await session.get(UserRolesModel, (user.id, parent.id))
                    if user_roles_model:
                        await session.delete(user_roles_model)
                user.role_ids.remove(parent.id)

    async def add_track_level(self, track: Track, role: Role, name: str | None = None) -> None:
        await self.loaded.wait()
        level = TrackLevel(role.id, name or role.name)
        if level in track.levels:
            return
        track.levels.append(level)
        async with get_session() as session, session.begin() as _:
            await session.merge(
                TrackLevelModel(
                    index=len(track.levels) - 1,
                    track_id=track.id,
                    role_id=level.role_id,
                    level_name=level.level_name,
                )
            )

    async def insert_track_level(self, track: Track, index: int, role: Role, name: str | None = None) -> None:
        await self.loaded.wait()
        level = TrackLevel(role.id, name or role.name)
        if level in track.levels:
            return
        track.levels.insert(index, level)
        async with get_session() as session, session.begin() as _:
            levels_to_update = (
                await session.scalars(
                    select(TrackLevelModel)
                    .where(TrackLevelModel.track_id == track.id)
                    .where(TrackLevelModel.index >= index)
                )
            ).all()
            for lvl in levels_to_update:
                lvl.index += 1
                session.add(lvl)
            await session.flush()
            track_level_model = TrackLevelModel(
                index=index,
                track_id=track.id,
                role_id=level.role_id,
                level_name=level.level_name,
            )
            await session.merge(track_level_model)

    async def remove_track_level(self, track: Track, role: Role) -> None:
        await self.loaded.wait()
        level = TrackLevel(role.id, role.name)
        if level not in track.levels:
            return
        level_index = track.levels.index(level)
        track.levels.remove(level)
        async with get_session() as session, session.begin() as _:
            level_model = await session.scalar(
                select(TrackLevelModel)
                .where(TrackLevelModel.track_id == track.id)
                .where(TrackLevelModel.role_id == role.id)
            )
            if level_model:
                await session.delete(level_model)
            levels_to_update = (
                await session.scalars(
                    select(TrackLevelModel)
                    .where(TrackLevelModel.track_id == track.id)
                    .where(TrackLevelModel.index > level_index)
                )
            ).all()
            for lvl in levels_to_update:
                lvl.index -= 1
                await session.merge(lvl)

    async def clear_track_levels(self, track: Track) -> None:
        await self.loaded.wait()
        track.levels.clear()
        async with get_session() as session, session.begin() as _:
            for level_model in (
                await session.scalars(select(TrackLevelModel).where(TrackLevelModel.track_id == track.id))
            ).all():
                await session.delete(level_model)

    async def update_track_name(self, track: Track, name: str):
        await self.loaded.wait()
        track.name = name
        async with get_session() as session, session.begin() as _:
            track_model = await session.get(TrackModel, track.id)
            if track_model:
                track_model.name = name

    async def set_user_track_level(self, user: User, track: Track, level_index: int) -> None:
        """将用户在某个 Track 上设置到指定等级。

        会清理该用户在该 Track 上已有的其他角色，并赋予新等级对应的角色。

        Args:
            user (User): 用户对象。
            track (Track): Track 对象。
            level_index (int): 目标等级索引。

        Raises:
            ValueError: 当 Track 没有等级或索引无效时抛出。
        """
        levels = track.levels
        if not levels:
            raise ValueError("Track has no levels.")
        if level_index >= len(levels):
            raise ValueError("Invalid level index.")
        track_role_ids = {level.role_id for level in levels}
        user.role_ids = [rid for rid in user.role_ids if rid not in track_role_ids]
        if level_index < 0:
            return
        if levels[level_index].role_id not in user.role_ids:
            user.role_ids.append(levels[level_index].role_id)
        async with get_session() as session, session.begin() as _:
            user_roles_to_delete = (
                await session.scalars(
                    select(UserRolesModel)
                    .where(UserRolesModel.user_id == user.id)
                    .where(UserRolesModel.role_id.in_(track_role_ids))
                )
            ).all()
            for ur in user_roles_to_delete:
                await session.delete(ur)
            new_role_id = levels[level_index].role_id
            user_roles_model = UserRolesModel(user_id=user.id, role_id=new_role_id)
            await session.merge(user_roles_model)
        publish(
            UserSetTrackLevel(user=user, track=track, level=levels[level_index])
        )

    async def update_acl(self, acl: AclEntry, allow_mask: Permission, deny_mask: Permission | None = None) -> None:
        await self.loaded.wait()
        async with get_session() as session, session.begin() as _:
            target = await session.scalar(
                select(AclEntryModel)
                .where(AclEntryModel.subject_type == acl.subject_type)
                .where(AclEntryModel.subject_id == acl.subject_id)
                .where(AclEntryModel.resource_id == acl.resource_id)
            )
            if not target:
                raise ValueError("ACL entry does not exist.")
            target.allow_mask = allow_mask
            if deny_mask is not None:
                target.deny_mask = deny_mask
            acl.allow_mask = allow_mask
            if deny_mask is not None:
                acl.deny_mask = deny_mask
