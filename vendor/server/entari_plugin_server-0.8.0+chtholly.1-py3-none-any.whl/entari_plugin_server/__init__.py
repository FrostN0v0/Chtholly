import re
import inspect
from dataclasses import make_dataclass, field
from functools import reduce
from importlib import import_module
from typing import TYPE_CHECKING, Any, Callable, Optional, Union, cast

from arclet.entari.config.models.default import BasicConfModel
from typing_extensions import TypeAlias

from arclet.entari import plugin
from arclet.entari.plugin import PluginRole, get_plugin
from arclet.entari.config import EntariConfig, config_model_validate, config_model_schema
from arclet.entari import logger as log_m

from arclet.letoderea.utils import TCallable
from graia.amnesia.builtins.asgi import uvicorn, asgitypes
from satori.server import Adapter, Server
from starlette.applications import Starlette
from starlette.types import ASGIApp

from .config import Config
from .patch import DirectAdapterServer, logger
from ._adapter import EntariAdapter

DISPOSE: TypeAlias = Callable[[], None]

uvicorn.LoguruHandler = log_m.LoguruHandler


plugin.declare_static()
plugin.metadata(
    "server",
    PluginRole.LIBRARY,
    [{"name": "RF-Tar-Railt", "email": "rf_tar_railt@qq.com"}],
    "0.8.0",
    description="为 Entari 提供 Satori 服务器支持，基于此为 Entari 提供 ASGI 服务、适配器连接等功能",
    urls={
        "homepage": "https://github.com/ArcletProject/entari-plugin-server",
    },
    config=Config,
    readme="README.md",
)


conf = plugin.get_config(Config)
_plg = plugin.get_plugin()

if conf.direct_adapter:
    server = DirectAdapterServer(conf.host, int(conf.port), conf.path, conf.version, conf.token, uvicorn_options=conf.options, stream_threshold=conf.stream_threshold, stream_chunk_size=conf.stream_chunk_size)  # type: ignore
else:
    server = Server(conf.host, int(conf.port), conf.path, conf.version, conf.token, uvicorn_options=conf.options, stream_threshold=conf.stream_threshold, stream_chunk_size=conf.stream_chunk_size)  # type: ignore

pattern = re.compile(r"(?P<module>[\w.]+)\s*(:\s*(?P<attr>[\w.]+)\s*)?((?P<extras>\[.*\])\s*)?$")

_adapter_schemas = []


def _load_adapter(adapter_config: dict):
    if "$path" not in adapter_config:
        logger.warning(f"Adapter config missing `$path`: {adapter_config}")
        return None
    path = adapter_config["$path"]
    if path.startswith("@."):
        path = f"satori.adapters{path[1:]}"
    elif path.startswith("@"):
        path = f"satori.adapters.{path[1:]}"
    match = pattern.match(path)
    if not match:
        logger.warning(f"Invalid adapter path: {path}")
        return None
    try:
        module = import_module(match.group("module"))
    except ImportError:
        logger.warning(f"Could not import module {match.group('module')}")
        return None
    try:
        attrs = filter(None, (match.group("attr") or "Adapter").split("."))
        ext = reduce(getattr, attrs, module)
    except AttributeError:
        for attr in module.__dict__.values():
            if isinstance(attr, type) and issubclass(attr, Adapter) and not inspect.isabstract(attr):
                ext = attr
                break
        else:
            logger.warning(f"Could not find adapter in {module.__name__}")
            return None
    if isinstance(ext, type) and issubclass(ext, Adapter) and ext is not Adapter:
        args: dict = {k: (log_m.logger_id if v == "$logger_id" else v) for k, v in adapter_config.items()}
        sig = inspect.signature(ext.__init__)
        annos = inspect.get_annotations(ext.__init__, globals=module.__dict__, locals=globals(), eval_str=True)
        if len(annos) == 1 and "config" in annos:
            config_cls = annos["config"]
            dcls = make_dataclass(
                "AdapterConfig",
                [],
                bases=(config_cls, BasicConfModel),
            )
            _schema = config_model_schema(
                dcls,
                ref_root=f"/$defs/adapter_{len(_adapter_schemas)}/"
            )
            _schema["properties"]["$path"] = {"const": adapter_config["$path"]}
            _schema["required"] = ["$path"]
            _adapter_schemas.append(_schema)
            dcls_instance = config_model_validate(dcls, args)
            return ext(dcls_instance)  # type: ignore
        filtered_args = {k: v for k, v in args.items() if k in sig.parameters}
        dcls = make_dataclass(
            "AdapterConfig",
            [
                (param.name, annos.get(param.name, sig.empty), field(default_factory=lambda p=param: p.default))
                for param in sig.parameters.values()
                if param.name != "self"
            ],
            bases=(BasicConfModel,),
        )
        _schema = config_model_schema(
            dcls,
            ref_root=f"/$defs/adapter_{len(_adapter_schemas)}/"
        )
        _schema["properties"]["$path"] = {"const": adapter_config["$path"]}
        _schema["required"] = ["$path"]
        _adapter_schemas.append(_schema)
        dcls_instance = config_model_validate(dcls, filtered_args)
        return ext(**vars(dcls_instance))
    elif isinstance(ext, Adapter):
        return ext
    logger.warning(f"Invalid adapter in {module.__name__}")
    return None


adapters: list[Adapter] = [*filter(None, map(_load_adapter, conf.adapters + EntariConfig.instance.data.get("adapters", [])))]

_plg.register_schema(
    "properties.adapters",
    {
        "type": "array",
        "items": {
            "oneOf": [{"$ref": f"#/$defs/adapter_{index}"} for index in range(len(_adapter_schemas))]
        } if _adapter_schemas else {"type": "object"},
        # Entari rebases fragment definitions for standalone and full-file schemas.
        "$defs": {f"adapter_{index}": schema for index, schema in enumerate(_adapter_schemas)},
        "title": "Adapters"
    },
    replace=True
)

for adapter in adapters:
    logger.debug(f"Applying adapter {adapter}")
    server.apply(adapter)

if conf.transfer_client:
    logger.debug("Applying Client Event Transfer")
    server.apply(EntariAdapter())

plugin.add_service(ASGI := server.asgi_service)
plugin.add_service(server)


def _remove_subsequence(seq, subseq):
    # 找到子序列的起始索引
    for i in range(len(seq) - len(subseq) + 1):
        if seq[i:i + len(subseq)] == subseq:
            return seq[:i] + seq[i + len(subseq):]
    return seq  # 如果没找到，返回原序列


def get_asgi() -> Any:
    return server.app


def replace_asgi(app: Union[ASGIApp, asgitypes.ASGI3Application]):
    """
    替换当前的 ASGI 应用

    Args:
        app (Any): 新的 ASGI 应用
    """
    plg = get_plugin(1)

    if server.status.blocking:
        logger.warning("Server is blocking, cannot replace ASGI app")
        return lambda: None

    def _():
        old_app = server.app
        old_routes = cast(Starlette, old_app).router.routes.copy()
        server.app = app
        server.app.router.routes[:0] = old_routes  # type: ignore

        def dispose(_old=old_app, _old_routes=old_routes):
            server.app.router.routes = _remove_subsequence(  # type: ignore
                cast(Starlette, server.app).router.routes, _old_routes
            )
            server.app = _old

        return dispose

    return plg.effect(_, "replace_asgi")


def add_route(
    path: str,
    *,
    methods: Optional[list[str]] = None,
    name: Optional[str] = None,
    include_in_schema: bool = True,
    **kwargs: Any,
) -> Callable[[TCallable], TCallable]:
    """注册一个 ASGI 路由

    Args:
        path (str): 路由路径
        methods (list[str], optional): 支持的 HTTP 方法，默认为 None，表示 ["GET"]
        name (str, optional): 路由名称，默认为 None
        include_in_schema (bool, optional): 是否包含在 OpenAPI 文档中，默认为 True
        kwargs (Any): 其他参数，例如 FastAPI 的路由参数
    """
    plg = get_plugin(1)

    def wrapper(endpoint: TCallable, /) -> TCallable:
        app = cast(Starlette, server.app)
        fn = getattr(app.router, "add_api_route", app.router.add_route)

        def _():
            fn(
                path, endpoint, methods=methods, name=name, include_in_schema=include_in_schema, **kwargs
            )
            route = app.router.routes[-1]
            return lambda: app.router.routes.remove(route)

        plg.effect(_, f"add_route {path} {methods}")
        return endpoint

    return wrapper


def add_websocket_route(
    path: str,
    *,
    name: Optional[str] = None,
    **kwargs: Any,
) -> Callable[[TCallable], TCallable]:
    """注册一个 ASGI WebSocket 路由

    Args:
        path (str): 路由路径
        name (str, optional): 路由名称，默认为 None
        kwargs (Any): 其他参数，例如 FastAPI 的路由参数
    """
    plg = get_plugin(1)

    def wrapper(endpoint: TCallable, /) -> TCallable:
        app = cast(Starlette, server.app)
        fn = getattr(app.router, "add_api_websocket_route", app.router.add_websocket_route)

        def _():
            fn(
                path, endpoint, name=name, **kwargs
            )
            route = app.router.routes[-1]
            return lambda: app.router.routes.remove(route)

        plg.effect(_, f"add_websocket_route {path}")
        return endpoint

    return wrapper


if TYPE_CHECKING:
    from fastapi import FastAPI
    from tarina import init_spec

    @init_spec(FastAPI)
    def replace_fastapi(data: FastAPI) -> DISPOSE:
        ...
else:
    def replace_fastapi(**kwargs):
        try:
            from fastapi import FastAPI
        except ImportError:
            logger.warning("FastAPI is not installed, cannot replace ASGI app with FastAPI")
            return lambda: None
        return replace_asgi(FastAPI(**kwargs))  # type: ignore

__all__ = [
    "ASGI",
    "server",
    "get_asgi",
    "replace_asgi",
    "add_route",
    "add_websocket_route",
    "replace_fastapi",
    "Config",
]
