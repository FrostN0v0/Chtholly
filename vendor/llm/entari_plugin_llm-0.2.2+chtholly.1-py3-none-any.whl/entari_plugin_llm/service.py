import time
from collections.abc import AsyncGenerator, AsyncIterator
from contextlib import aclosing
from typing import Any, Literal, TypeVar, cast, overload

import litellm
from agno.agent import Agent
from agno.db.sqlite import AsyncSqliteDb
from agno.models.litellm import LiteLLM
from agno.models.message import Message
from agno.run.agent import RunErrorEvent, RunOutput, RunOutputEvent
from agno.run.base import RunStatus
from arclet.entari import Session, add_service, local_data
from arclet.letoderea import Contexts
from launart import Launart, Service
from launart.status import Phase

from ._callback import TokenUsageHandler
from .config import _conf, get_model_config
from .response import GenericResponse
from .runtime import ToolExecutors, run_llm_tools
from .sessions import AgnoSessionStore, SessionInfo
from .tools import get_agno_tools

TOutput = TypeVar("TOutput")
OutputType = Literal["json_object"] | type[Any] | dict[str, Any]


class LLMService(Service):
    id = "entari_plugin_llm"

    def __init__(self) -> None:
        super().__init__()
        self.total_tokens = 0
        self.total_calls = 0
        self.start_time: float = 0.0
        self.usage_handler = TokenUsageHandler(self)
        self._db: AsyncSqliteDb | None = None
        self._sessions: AgnoSessionStore | None = None

    @property
    def required(self) -> set[str]:
        return set()

    @property
    def stages(self) -> set[Phase]:
        return {"preparing", "blocking", "cleanup"}

    @property
    def session_store(self) -> AgnoSessionStore:
        if self._sessions is None:
            raise RuntimeError("Agno session store is not initialized")
        return self._sessions

    @overload
    async def generate(
        self,
        message: str | list[Message],
        variables: dict[str, Any] | None = None,
        *,
        stream: bool = False,
        system: str | None = None,
        model: str | None = None,
        output: type[TOutput],
        ignore_user_prompt: bool = False,
        **kwargs: Any,
    ) -> GenericResponse[TOutput]: ...

    @overload
    async def generate(
        self,
        message: str | list[Message],
        variables: dict[str, Any] | None = None,
        *,
        stream: bool = False,
        system: str | None = None,
        model: str | None = None,
        output: Literal["json_object"] | dict[str, Any],
        ignore_user_prompt: bool = False,
        **kwargs: Any,
    ) -> GenericResponse[Any]: ...

    @overload
    async def generate(
        self,
        message: str | list[Message],
        variables: dict[str, Any] | None = None,
        *,
        stream: bool = False,
        system: str | None = None,
        model: str | None = None,
        output: None = None,
        ignore_user_prompt: bool = False,
        **kwargs: Any,
    ) -> GenericResponse[None]: ...

    async def generate(
        self,
        message: str | list[Message],
        variables: dict[str, Any] | None = None,
        *,
        stream: bool = False,
        system: str | None = None,
        model: str | None = None,
        output: OutputType | None = None,
        ignore_user_prompt: bool = False,
        **kwargs: Any,
    ) -> GenericResponse[Any]:
        """Generate a stateless LLM response through an Agno Agent."""
        if "session_id" in kwargs or "user_id" in kwargs:
            raise TypeError("session_id and user_id are reserved for Entari chat persistence")
        return await self._run_agent(
            message,
            variables,
            stream=stream,
            system=system,
            model=model,
            output=output,
            llm_session=None,
            ignore_user_prompt=ignore_user_prompt,
            request_params=kwargs,
        )

    async def _generate_for_session(
        self,
        message: str | list[Message],
        variables: dict[str, Any] | None = None,
        *,
        llm_session: SessionInfo,
        model: str | None = None,
        ctx: Contexts | None = None,
        session: Session | None = None,
    ) -> GenericResponse[None]:
        """Generate a persisted response for Entari's chat session manager."""
        return await self._run_agent(
            message,
            variables,
            stream=False,
            system=None,
            model=model,
            output=None,
            llm_session=llm_session,
            ignore_user_prompt=False,
            request_params={},
            ctx=ctx,
            session=session,
        )

    async def _run_agent(
        self,
        message: str | list[Message],
        variables: dict[str, Any] | None,
        *,
        stream: bool,
        system: str | None,
        model: str | None,
        output: OutputType | None,
        llm_session: SessionInfo | None,
        ignore_user_prompt: bool,
        request_params: dict[str, Any],
        ctx: Contexts | None = None,
        session: Session | None = None,
    ) -> GenericResponse[Any]:
        if output is not None and stream:
            raise ValueError("output is not supported when stream=True")

        model_config = get_model_config(model)
        tools, executors = get_agno_tools()

        if system is not None:
            instructions = system
        elif ignore_user_prompt:
            instructions = None
        else:
            instructions = model_config.prompt or _conf.prompt or None

        if variables:
            variable_instructions = "下列是用以辅助你思考回答的变量：\n" + "\n".join(
                f"- **{key}**: {value!r}" for key, value in variables.items()
            )
            instructions = f"{instructions}\n\n{variable_instructions}" if instructions else variable_instructions

        model_request_params = {**model_config.extra, **request_params}
        agno_model = LiteLLM(
            id=model_config.name,
            api_key=model_config.api_key,
            api_base=model_config.base_url,
            request_params=model_request_params or None,
        )

        agent_kwargs: dict[str, Any] = {
            "id": self.id,
            "model": agno_model,
            "instructions": instructions,
            "tools": tools,
            "markdown": False,
        }
        if output is not None:
            agent_kwargs["output_schema"] = output if output != "json_object" else {"type": "object"}
            agent_kwargs["use_json_mode"] = True
        if llm_session is not None:
            if self._db is not None:
                agent_kwargs["db"] = self._db
            agent_kwargs["session_id"] = llm_session.session_id
            agent_kwargs["user_id"] = str(llm_session.user_id)
            agent_kwargs["add_history_to_context"] = True
            agent_kwargs["enable_session_summaries"] = True
            agent_kwargs["add_session_summary_to_context"] = False

        agent = Agent(**agent_kwargs)
        if stream:
            return GenericResponse.from_stream(self._stream_agent(agent, message, executors, llm_session, session, ctx))

        response = await agent.arun(message)
        while await self._should_continue(response, executors, llm_session, session, ctx):
            response = await agent.acontinue_run(run_response=response, requirements=response.requirements)
        return GenericResponse.from_run_output(
            response, structured=output is not None, stopped=response.is_paused or response.is_cancelled
        )

    async def _should_continue(
        self,
        response: RunOutput,
        executors: ToolExecutors,
        llm_session: SessionInfo | None,
        session: Session | None,
        ctx: Contexts | None,
    ) -> bool:
        if response.status is RunStatus.error:
            raise RuntimeError(str(response.content or "Agno agent run failed"))
        if not response.is_paused:
            return False
        return await run_llm_tools(response, executors, llm_session, session, ctx)

    async def _stream_agent(
        self,
        agent: Agent,
        message: str | list[Message],
        executors: ToolExecutors,
        llm_session: SessionInfo | None,
        session: Session | None,
        ctx: Contexts | None,
    ) -> AsyncIterator[RunOutputEvent | RunOutput]:
        stream = cast(
            AsyncGenerator[RunOutputEvent | RunOutput, None],
            agent.arun(message, stream=True, yield_run_output=True),
        )
        while True:
            response: RunOutput | None = None
            error: RunErrorEvent | None = None
            async with aclosing(stream):
                async for event in stream:
                    if isinstance(event, RunOutput):
                        response = event
                    else:
                        if isinstance(event, RunErrorEvent):
                            error = event
                        yield event

            if error is not None:
                raise RuntimeError(str(error.content or "Agno agent run failed"))
            if response is None:
                raise RuntimeError("Agno stream ended without a run output")
            if not await self._should_continue(response, executors, llm_session, session, ctx):
                yield response
                return

            stream = cast(
                AsyncGenerator[RunOutputEvent | RunOutput, None],
                agent.acontinue_run(
                    run_response=response, requirements=response.requirements, stream=True, yield_run_output=True
                ),
            )

    async def vision(
        self,
        image_url: str | dict[str, Any],
        system: str | None = None,
        model: str | None = None,
    ) -> GenericResponse[None]:
        """Describe an image through the standard generate path."""
        model_config = get_model_config(model)
        if not litellm.supports_vision(model_config.name):
            raise RuntimeError(f"Model {model_config.name} does not support vision input")

        if isinstance(image_url, str):
            url = image_url
        else:
            image = image_url.get("image_url", image_url)
            url = image["url"] if isinstance(image, dict) else str(image)
        message = Message(
            role="user",
            content=[
                {"type": "text", "text": "Describe this image."},
                {"type": "image_url", "image_url": {"url": url}},
            ],
        )
        return await self.generate([message], system=system, model=model_config.name)

    async def launch(self, manager: Launart) -> None:
        async with self.stage("preparing"):
            litellm.drop_params = True
            litellm.callbacks = [self.usage_handler]
            self.start_time = time.time()
            db_path = local_data.get_data_file("entari_plugin_llm", "agno.db")
            self._db = AsyncSqliteDb(db_file=str(db_path))
            self._sessions = AgnoSessionStore(self._db, self.id)

        async with self.stage("blocking"):
            await manager.status.wait_for_sigexit()

        async with self.stage("cleanup"):
            if self._db is not None:
                await self._db.db_engine.dispose()


llm = LLMService()
add_service(llm)
