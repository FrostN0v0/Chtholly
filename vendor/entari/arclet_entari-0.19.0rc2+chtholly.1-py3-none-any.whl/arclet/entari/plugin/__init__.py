import asyncio
import inspect
import itertools
import os
import sys
from collections.abc import Awaitable
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal, TypeVar, overload

from arclet.letoderea import Subscriber, on
from arclet.letoderea.effect import AsyncDisposable, Disposable
from arclet.letoderea.utils import Resultable
from tarina import init_spec
from tarina.tools import nest_obj_update

from ..config import EntariConfig, config_model_keys, config_model_validate
from ..event.config import ConfigReload
from ..exceptions import StaticPluginDispatchError
from ..message import Fragment, MessageChain, Render
from ..session import COMPONENTS, Session, component_transform
from .loader import find_plugin as find_plugin
from .loader import load_plugin as load_plugin
from .loader import reload_plugin as reload_plugin
from .loader import reload_subplugin as reload_subplugin
from .loader import unload_plugin as unload_plugin
from .model import TS, Plugin, PluginDispatcher, current_plugin
from .model import PluginMetadata as PluginMetadata
from .model import PluginRole as PluginRole
from .model import RootlessPlugin as RootlessPlugin
from .model import keeping as keeping
from .module import package as package
from .module import requires as requires
from .service import plugin_service

T = TypeVar("T")


@overload
def get_plugin(depth: int = 0) -> Plugin: ...


@overload
def get_plugin(depth: int = 0, *, optional: Literal[True]) -> Plugin | None: ...


def get_plugin(depth: int = 0, *, optional: bool = False) -> Plugin | None:
    """获取当前插件上下文

    Args:
        depth (int, optional): 获取的深度，默认为0，表示当前插件上下文. Defaults to 0.
        optional (bool, optional): 是否允许返回None，默认为False. Defaults to False.
    Raises:
        ValueError: 如果深度超出范围
        LookupError: 如果没有找到插件上下文
    Returns:
        Plugin | None: 当前插件上下文，如果没有找到且optional为True则返回None
    """
    if plugin := current_plugin.get(None):
        return plugin
    current_frame = inspect.currentframe()
    if current_frame is None:
        if optional:
            return None
        raise ValueError("Depth out of range")
    frame = current_frame
    d = depth + 1
    while d > 0:
        frame = frame.f_back
        if frame is None:
            if optional:
                return None
            raise ValueError("Depth out of range")
        d -= 1
    locals_ = frame.f_locals
    if "__plugin__" in locals_:
        return locals_["__plugin__"]
    globals_ = frame.f_globals
    if "__plugin__" in globals_:
        return globals_["__plugin__"]
    if optional:
        return None
    raise LookupError("no plugin context found")


def get_plugins(subplugged: bool = False):
    """获取所有插件

    Args:
        subplugged (bool, optional): 是否包含子插件. Defaults to False.
    """
    if subplugged:
        return list(plugin_service.plugins.values())
    return [p for pid, p in plugin_service.plugins.items() if pid not in plugin_service._subplugined]


def get_plugin_subscribers(plug: Plugin | str | None = None) -> list[Subscriber]:
    """获取指定插件的所有订阅者"""
    if isinstance(plug, Plugin):
        plg = plug
    elif plug in plugin_service.plugins:
        plg = plugin_service.plugins[plug]
    else:
        plg = get_plugin(1)
    return [s.subscriber for s in plg._scope.subscribers]


def get_all_subscribers():
    """获取所有插件的所有订阅者"""
    return list(itertools.chain.from_iterable(get_plugin_subscribers(plug) for plug in plugin_service.plugins.values()))


def get_plugin_references(plug: Plugin | str | None = None) -> set[str]:
    """获取指定插件引用的所有插件

    Args:
        plug (Plugin | str | None, optional): 插件对象或插件名称. Defaults to None.
    """
    if isinstance(plug, Plugin):
        plg = plug
    elif plug in plugin_service.plugins:
        plg = plugin_service.plugins[plug]
    else:
        plg = get_plugin(1)
    return plugin_service.references.get(plg.id, set()).copy()


def get_plugin_referents(plug: Plugin | str | None = None) -> set[str]:
    """获取引用了指定插件的所有插件

    Args:
        plug (Plugin | str | None, optional): 插件对象或插件名称. Defaults to None.
    """
    if isinstance(plug, Plugin):
        plg = plug
    elif plug in plugin_service.plugins:
        plg = plugin_service.plugins[plug]
    else:
        plg = get_plugin(1)
    return plugin_service.referents.get(plg.id, set()).copy()


def get_plugin_kept_ids(plug: Plugin | str | None = None) -> list[str]:
    """获取指定插件的所有保持变量的 ID

    Args:
        plug (Plugin | str | None, optional): 插件对象或插件名称. Defaults to None.
    """
    if isinstance(plug, Plugin):
        plg = plug
    elif plug in plugin_service.plugins:
        plg = plugin_service.plugins[plug]
    else:
        plg = get_plugin(1)
    return plg._extra.get("kept_variables", [])


def get_plugin_commands(plug: Plugin | str | None = None) -> list[tuple[list[str], str]]:
    """获取指定插件的所有命令

    Args:
        plug (Plugin | str | None, optional): 插件对象或插件名称. Defaults to None.
    """
    if isinstance(plug, Plugin):
        plg = plug
    elif plug in plugin_service.plugins:
        plg = plugin_service.plugins[plug]
    else:
        plg = get_plugin(1)
    return plg._extra.get("commands", [])


def get_plugin_depend_services(plug: Plugin | str | None = None) -> list[str]:
    """获取指定插件依赖的所有服务的 ID

    Args:
        plug (Plugin | str | None, optional): 插件对象或插件名称. Defaults to None.
    """
    if isinstance(plug, Plugin):
        plg = plug
    elif plug in plugin_service.plugins:
        plg = plugin_service.plugins[plug]
    else:
        plg = get_plugin(1)
    injected_services = plg._extra.get("injected_services", [])
    local_injected_services = plg._extra.get("local_injected_services", [])
    services = injected_services[:]
    for slot in local_injected_services:
        services.extend(slot[1])
    return list(set(services))


@overload
def dispatch(event: type[Resultable[T]], name: str | None = None) -> PluginDispatcher[T]: ...
@overload
def dispatch(event: type[Any], name: str | None = None) -> PluginDispatcher[Any]: ...


def dispatch(event: type, name: str | None = None) -> PluginDispatcher:
    """对当前插件创建一个事件分发"""
    return get_plugin(1).dispatch(event, name=name)


if TYPE_CHECKING:

    @init_spec(PluginMetadata)
    def metadata(data: PluginMetadata) -> None:
        """声明当前插件的元数据"""

else:

    def metadata(*args, **kwargs):
        """声明当前插件的元数据"""
        get_plugin(1).metadata = PluginMetadata(*args, **kwargs)  # type: ignore


_C = TypeVar("_C")


@overload
def plugin_config() -> dict[str, Any]: ...


@overload
def plugin_config(model_type: type[_C], bind: bool = False) -> _C: ...


def plugin_config(model_type: type[_C] | None = None, bind: bool = False):
    """获取当前插件的配置

    Args:
        model_type (type[_C], optional): 配置模型类型. Defaults to None.
        bind (bool, optional): 是否将配置模型与配置绑定，绑定后配置模型的修改会更新配置文件,
            而配置文件的修改则直接作用在配置模型上，不再重载整个插件. Defaults to False.
    """
    plugin = get_plugin(1)
    plg_config = plugin.config
    if model_type:
        obj = config_model_validate(model_type, plg_config)
        if bind:
            plugin_key = plugin._config_key

            def _reload(event: ConfigReload):
                if event.scope != "plugin":
                    return
                if event.key != plugin_key:
                    return
                new_plg_config = event.value
                keys = [
                    k
                    for k in new_plg_config
                    if k.startswith(".") and plugin.id.startswith(f"{plugin.id.split('.')[0]}{k}")
                ]
                if keys:
                    key = max(keys, key=len)
                    new_plg_config = new_plg_config[key]
                new = config_model_validate(model_type, new_plg_config)
                nest_obj_update(obj, new, config_model_keys(new))
                return True

            plugin._scope.register(_reload, event=ConfigReload)
            proxy = EntariConfig.instance.bind(plugin_key, plg_config, obj)
            plugin.collect(lambda: delattr(proxy, "_Proxy__origin"))
            return proxy
        return obj
    return plg_config


get_config = plugin_config


def load_plugins(dir_: str | os.PathLike | Path):
    """加载指定目录下的所有插件"""
    path = dir_ if isinstance(dir_, Path) else Path(dir_)
    if not path.is_dir():
        raise NotADirectoryError(f"{path} is not a directory")
    path: Path = path.resolve()  # .relative_to(Path.cwd())
    syspaths = [Path(p).resolve() for p in sys.path if p]
    prefixes = [p for p in syspaths if path.is_relative_to(p)]
    if prefixes:
        prefix = max(prefixes, key=lambda p: len(p.parts))
    else:
        prefix = Path.cwd()
    for p in path.iterdir():
        if p.suffix in (".py", "") and p.stem not in {"__init__", "__pycache__"}:
            p = p.resolve().relative_to(prefix)
            if len(p.parts) > 1:
                plg = ".".join(p.parts[:-1:1]) + "." + p.stem
            else:
                plg = p.stem
            load_plugin(plg)


def find_plugin_by_file(file: str) -> Plugin | None:
    path = Path(file).resolve()
    for plugin in plugin_service.plugins.values():
        if plugin.module.__file__ == str(path):
            return plugin
        if plugin.module.__file__ and Path(plugin.module.__file__).parent == path:
            return plugin
        path1 = Path(path)
        while path1.parent != path1:
            if str(path1) == plugin.module.__file__:
                return plugin
            path1 = path1.parent
    return None


def declare_static():
    """声明当前插件为静态插件"""
    _plugin = get_plugin(1)
    _plugin.is_static = True
    if _plugin._scope.subscribers:
        raise StaticPluginDispatchError("static plugin cannot dispatch events")
    _plugin_id = _plugin.id
    while _plugin_id in plugin_service._subplugined:
        _plugin_id = plugin_service._subplugined[_plugin_id]
        if plugin := find_plugin(_plugin_id):
            plugin.is_static = True
            if plugin._scope.subscribers:
                raise StaticPluginDispatchError("static plugin cannot dispatch events")


def add_service(serv: TS | type[TS]) -> TS:
    """添加一个服务到当前插件"""
    return get_plugin(1).service(serv)


def collect_disposes(*disposes: Disposable | AsyncDisposable):
    """收集副作用回收函数"""
    return get_plugin(1).collect(*disposes)


def restore():
    """回收该插件收集的所有副作用"""
    return get_plugin(1).restore()


async def unload_plugin_async(plugin: str):
    plugin = plugin.replace("::", "arclet.entari.builtins.")
    while plugin in plugin_service._subplugined:
        plugin = plugin_service._subplugined[plugin]
    if not (_plugin := find_plugin(plugin)):
        return False
    if tasks := _plugin.dispose():
        await asyncio.wait(tasks)
    return True


async def enable_plugin(plugin: str):
    """启用指定插件"""
    plugin = plugin.replace("::", "arclet.entari.builtins.")
    while plugin in plugin_service._subplugined:
        plugin = plugin_service._subplugined[plugin]
    if not (_plugin := find_plugin(plugin)):
        return False
    if tasks := _plugin.enable():
        await asyncio.wait(tasks)
    return True


async def disable_plugin(plugin: str):
    """禁用指定插件"""
    plugin = plugin.replace("::", "arclet.entari.builtins.")
    while plugin in plugin_service._subplugined:
        plugin = plugin_service._subplugined[plugin]
    if not (_plugin := find_plugin(plugin)):
        return False
    if tasks := _plugin.disable():
        await asyncio.wait(tasks)
    return True


listen = on


def component(name: str):
    _plugin = get_plugin(1)

    def wrapper(func: Render[Session, Awaitable[Fragment]]):
        async def render(attrs: dict, children: list, session: Session):
            ans = await func(attrs, children, session)
            return await component_transform(session, MessageChain(ans))

        def _():
            COMPONENTS[f"component:{name}"] = render
            return lambda: COMPONENTS.pop(f"component:{name}", None)

        _plugin.effect(_, f"component:{name}")
        return func

    return wrapper
