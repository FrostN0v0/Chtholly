import ast
import inspect
import re
import sys
import tokenize
from collections.abc import Sequence
from importlib import _bootstrap, _bootstrap_external  # type: ignore
from importlib.machinery import ExtensionFileLoader, ModuleSpec, PathFinder, SourceFileLoader
from importlib.metadata import Distribution, PackageNotFoundError, distribution, distributions
from importlib.util import module_from_spec, resolve_name
from io import BytesIO
from os import PathLike
from pathlib import Path
from types import ModuleType
from typing import Any

from arclet.letoderea import publish
from arclet.letoderea.scope import scope_ctx

from ..config import EntariConfig
from ..event.lifespan import Ready
from ..event.plugin import PluginLoadedFailed, PluginLoadedSuccess
from ..exceptions import RegisterNotInPluginError, ReusablePluginError, StaticPluginDispatchError
from ..logger import log
from .model import Plugin, PluginInspect, PluginMetadata, current_plugin
from .service import plugin_service

_SUBMODULE_WAITLIST: dict[str, set[str]] = {}
_ENSURE_IS_PLUGIN: set[str] = set()
_IMPORTING = set()

PLUGIN_PAT = re.compile(r"entari:\s*plugin")
SUBPLUGIN_PAT = re.compile(r"entari:\s*(?:package|subplugin)")
NAMESPACE_PAT = re.compile(r"entari:\s*namespace")

PLUGIN_CLASSIFIERS = {
    "Entari::Plugin" "Entari :: Plugin",
    "Framework :: Arclet Entari :: Plugin",
}
PLUGIN_KEYWORDS = {
    "entari",
    "entari_plugin",
    "entari-plugin",
    "entari:plugin",
    "Entari",
    "Entari-Plugin",
    "Entari:Plugin",
}


def package(*names: str | ModuleType):
    """手动指定特定模块作为插件的子模块"""
    if not (plugin := current_plugin.get(None)):
        raise LookupError("no plugin context found")
    _SUBMODULE_WAITLIST.setdefault(plugin.module.__name__, set()).update(
        [n if isinstance(n, str) else n.__name__ for n in names]
    )


def requires(*names: str | ModuleType):
    """手动指定哪些模块是插件"""
    _ENSURE_IS_PLUGIN.update(
        n.replace("::", "arclet.entari.builtins.") if isinstance(n, str) else n.__name__ for n in names
    )


def _ensure_plugin(names: list[str], sub: bool, pid: str, pname: str, prefix=""):
    for name in names:
        if sub:
            _SUBMODULE_WAITLIST.setdefault(pname, set()).add(f"{prefix}{name}")
        else:
            _ENSURE_IS_PLUGIN.add(f"{prefix}{name}")
            plugin_service.referents.setdefault(f"{prefix}{name}", set()).add(pid)
            plugin_service.references.setdefault(pname, set()).add(f"{prefix}{name}")
        _IMPORTING.add(f"{prefix}{name}")


def _resolve_from_target(node: ast.ImportFrom, pname: str, is_init: bool) -> str | None:
    """from-import 的目标模块全限定名（相对导入按当前模块解析）"""
    if node.level == 0:
        return node.module
    parts = pname.split(".")
    pkg = parts if is_init else parts[:-1]
    if node.level > len(pkg) + 1:
        return None
    base = pkg if node.level == 1 else pkg[: 1 - node.level]
    if node.module:
        return ".".join([*base, node.module])
    return ".".join(base) if base else None


def _record_binding(pid: str, name: str, target: str, attr: str | None):
    """记录名字级 import 绑定（name → (target, attr)），供重载侧查询与改写"""
    if not target:
        return
    plugin_service.bindings.setdefault(pid, {})[name] = (target, attr)


# fmt: off
class _Visitor(ast.NodeVisitor):
    def __init__(self, pid: str, pname: str, path: bytes | str | PathLike[str], plg_lineno: list[int], sub_lineno: list[int], ns_lineno: list[int]):  # noqa: E501
        self.pid = pid
        self.pname = pname
        self.path = path.decode() if isinstance(path, bytes) else f"{Path(path)}"
        self.signed_plugin_lineno = plg_lineno
        self.signed_subplugin_lineno = sub_lineno
        self.signed_namespace_lineno = ns_lineno
        self.signed_namespace_modules = set()
        self.type_checking_stack = []
        self.typing_aliases = {"typing", "typing_extensions"}  # 跟踪typing模块的别名

    def visit_Import(self, node: ast.Import):
        # 跟踪typing模块的导入别名
        for alias in node.names:
            if alias.name in ("typing", "typing_extensions"):
                self.typing_aliases.add(alias.asname or alias.name)

        if self._in_type_checking():
            return
        for alias in node.names:
            _record_binding(self.pid, alias.asname or alias.name.split(".")[0], alias.name, None)
        if node.lineno in self.signed_plugin_lineno or all(x.name in _ENSURE_IS_PLUGIN for x in node.names):
            _ensure_plugin([alias.name for alias in node.names], False, self.pid, self.pname)
        elif node.lineno in self.signed_subplugin_lineno or all(x.name in _SUBMODULE_WAITLIST.get(self.pname, ()) for x in node.names):  # noqa: E501
            _ensure_plugin([alias.name for alias in node.names], True, self.pid, self.pname)

    def visit_ImportFrom(self, node: ast.ImportFrom):
        name = self.pname
        if self._in_type_checking():
            return
        target = _resolve_from_target(node, name, self.path.endswith("__init__.py"))
        if target:
            for alias in node.names:
                if alias.name == "*":
                    continue
                if node.level == 1 and node.module is None:
                    _record_binding(self.pid, alias.asname or alias.name, f"{target}.{alias.name}", None)
                else:
                    _record_binding(self.pid, alias.asname or alias.name, target, alias.name)
        if node.module is None:  # from . import xxx
            _ensure_plugin([alias.name for alias in node.names], node.lineno not in self.signed_plugin_lineno, self.pid, name, f"{name}.")  # noqa: E501
        elif node.level == 0:  # from xxx import xxx
            if node.module in (*sys.builtin_module_names, *getattr(sys, "stdlib_module_names", [])):
                return
            if node.lineno in self.signed_plugin_lineno or node.module in _ENSURE_IS_PLUGIN:
                _ensure_plugin([node.module], False, self.pid, name)
            elif node.lineno in self.signed_subplugin_lineno or node.module in _SUBMODULE_WAITLIST.get(name, ()):
                _ensure_plugin([node.module], True, self.pid, name)
        elif node.level == 1:  # from .xxx import xxx
            if node.lineno in self.signed_plugin_lineno:
                pname = f"{name}.{node.module}"
                _ensure_plugin([alias.name for alias in node.names], False, self.pid, pname, f"{pname}.")  # noqa: E501
            elif node.lineno in self.signed_namespace_lineno or node.module in self.signed_namespace_modules:
                self.signed_namespace_modules.add(node.module)
                pname = f"{name}.{node.module}"
                _ensure_plugin([alias.name for alias in node.names], False, self.pid, pname, f"{pname}.")
            prefix = name if self.path.endswith("__init__.py") else name.rpartition(".")[0]
            _ensure_plugin([node.module], True, self.pid, prefix, f"{prefix}.")
        else:  # from ..xxx import xxx
            prefix = ".".join(name.split(".")[: -node.level + 1 if self.path.endswith("__init__.py") else -node.level])
            if not prefix:  # relative import beyond top-level package
                return
            if prefix not in plugin_service.plugins and prefix not in _ENSURE_IS_PLUGIN:
                is_sub = prefix in _SUBMODULE_WAITLIST.get(name, ())
                pname = name
            else:
                is_sub = True
                pname = prefix
            _ensure_plugin([node.module], is_sub, self.pid, pname, f"{prefix}.")

    def visit_If(self, node: ast.If):
        is_type_checking = self._is_type_checking(node)
        if is_type_checking:
            self.type_checking_stack.append(True)
        self.generic_visit(node)
        if is_type_checking:
            self.type_checking_stack.pop()

    def visit_Call(self, node):
        # 寻找 `requires(...)` 和 `package(...)` 调用
        if isinstance(node.func, ast.Name) and node.func.id == "requires":
            names = []
            for arg in node.args:
                if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                    names.append(arg.value)
                elif isinstance(arg, ast.Name):
                    names.append(arg.id)
                elif isinstance(arg, ast.Attribute):
                    value = arg.value
                    if isinstance(value, ast.Name):
                        names.append(f"{value.id}.{arg.attr}")
            if names:
                _ensure_plugin(names, False, self.pid, self.pname)
        elif isinstance(node.func, ast.Name) and node.func.id == "package":
            names = []
            for arg in node.args:
                if isinstance(arg, ast.Constant) and isinstance(arg.value, str):
                    names.append(arg.value)
            if names:
                _ensure_plugin(names, True, self.pid, self.pname)
        self.generic_visit(node)

    def _in_type_checking(self) -> bool:
        return len(self.type_checking_stack) > 0

    def _is_type_checking(self, node: ast.If) -> bool:
        test = node.test
        if isinstance(test, ast.Name) and test.id == "TYPE_CHECKING":
            return True
        if isinstance(test, ast.Attribute):
            if isinstance(test.value, ast.Name) and test.value.id in self.typing_aliases and test.attr == "TYPE_CHECKING":  # noqa: E501
                return True
        if isinstance(test, ast.Compare):
            left = test.left
            if isinstance(left, ast.Name) and left.id == "TYPE_CHECKING":
                return True
            elif isinstance(left, ast.Attribute):
                if isinstance(left.value, ast.Name) and left.value.id in self.typing_aliases and left.attr == "TYPE_CHECKING":  # noqa: E501
                    return True
        return False
# fmt: on


class PluginLoader(SourceFileLoader):
    def __init__(self, fullname: str, path: str, plugin_id: str, parent_plugin_id: str | None = None) -> None:
        self.loaded = False
        self.plugin_id = plugin_id
        self.parent_plugin_id = parent_plugin_id
        self._inspect: PluginInspect = None  # type: ignore
        self.staged = False
        super().__init__(fullname, path)

    def get_code(self, fullname):
        """Concrete implementation of InspectLoader.get_code.

        Reading of bytecode requires path_stats to be implemented. To write
        bytecode, set_data must also be implemented.

        """
        source_path = self.get_filename(fullname)
        # --- SourceFileLoader's cache handler removed ---
        source_bytes = self.get_data(source_path)
        code_object = self.source_to_code(source_bytes, source_path)
        return code_object

    def source_to_code(self, data, path="<string>", *, _optimize: int = -1):
        """Return the code object compiled from source.

        The 'data' argument can be any object type that compile() supports.
        """
        if not isinstance(data, bytes):
            return _bootstrap._call_with_frames_removed(  # type: ignore
                compile, data, path, "exec", dont_inherit=True, optimize=-1
            )
        name = self.name
        plg_lineno = []
        sub_lineno = []
        ns_lineno = []
        for token in tokenize.tokenize(BytesIO(data).readline):
            if token.type == tokenize.COMMENT:
                if PLUGIN_PAT.search(token.string):
                    plg_lineno.append(token.start[0])
                elif SUBPLUGIN_PAT.search(token.string):
                    sub_lineno.append(token.start[0])
                elif NAMESPACE_PAT.search(token.string):
                    ns_lineno.append(token.start[0])

        try:
            nodes = ast.parse(data, type_comments=True)
        except SyntaxError:
            return _bootstrap._call_with_frames_removed(  # type: ignore
                compile, data, path, "exec", dont_inherit=True, optimize=_optimize
            )
        visitor = _Visitor(self.plugin_id, name, path, plg_lineno, sub_lineno, ns_lineno)
        visitor.visit(nodes)
        self._inspect = PluginInspect(nodes, ast.dump(nodes, include_attributes=False))
        return _bootstrap._call_with_frames_removed(  # type: ignore
            compile, nodes, path, "exec", dont_inherit=True, optimize=_optimize
        )

    def create_module(self, spec) -> ModuleType | None:
        if self.staged:
            return super().create_module(spec)
        if self.name in plugin_service.plugins:
            self.loaded = True
            return plugin_service.plugins[self.name].proxy()
        if self.name in plugin_service._subplugined:
            self.loaded = True
            return plugin_service.plugins[plugin_service._subplugined[self.name]].subproxy(self.name)
        _check_reusable(self.name, self.plugin_id)
        return super().create_module(spec)

    def exec_module(self, module: ModuleType, config: dict[str, Any] | None = None) -> None:
        is_sub = False
        plugin = (
            # 暂存期间 plugins 中仍是旧顶插件，须优先取 _staged 中的新插件，
            # 否则新子插件的父链接指向旧插件
            (plugin_service._staged.get(self.parent_plugin_id) or plugin_service.plugins.get(self.parent_plugin_id))
            if self.parent_plugin_id
            else None
        )
        if plugin:
            if self.plugin_id not in plugin.subplugins:
                plugin.subplugins.append(self.plugin_id)
            plugin_service._subplugined[self.plugin_id] = plugin.id
            is_sub = True
            if config is None or not {k: v for k, v in config.items() if k not in ("$path", "$static")}:
                config = plugin.config.copy()
                config["$path"] = plugin._config_key
            keys = [k for k in config if k.startswith(".") and self.plugin_id.startswith(f"{self.parent_plugin_id}{k}")]
            if keys:
                key = max(keys, key=len)
                config = config[key]
                config["$path"] = plugin._config_key  # type: ignore

        if self.loaded:
            return

        if config is None or (not is_sub and not {k: v for k, v in config.items() if k not in ("$path", "$static")}):
            key = module.__name__
            if key.startswith("arclet.entari.builtins.") and f"::{key[23:]}" in EntariConfig.instance.plugin:
                key = f"::{key[23:]}"
            config = EntariConfig.instance.plugin.get(key)
            if config is not None:
                config["$path"] = key
            else:
                for k, names in EntariConfig.instance._plugin_names.items():
                    if key in names:
                        config = EntariConfig.instance.plugin.get(k, {})
                        config["$path"] = k
                        break
                else:
                    config = {"$path": key}
            if key in EntariConfig.instance.prelude_plugin:
                config["$static"] = True  # type: ignore
        # create plugin before executing
        plugin = Plugin(self.plugin_id, module, config=config)
        # for `dataclasses` module
        sys.modules[module.__name__] = plugin.proxy()  # type: ignore
        setattr(module, "__plugin__", plugin)

        # enter plugin context
        token = current_plugin.set(plugin)
        if not plugin.is_static:
            token1 = scope_ctx.set(plugin._scope)
        try:
            code = self.get_code(module.__name__)
            if code is None:
                raise ImportError(f"cannot load module {module.__name__r} when get_code() returns None")
            _bootstrap._call_with_frames_removed(exec, code, module.__dict__)  # type: ignore
        except RegisterNotInPluginError as e:
            deleted = []
            for frame in reversed(inspect.trace()):
                if Path(frame.filename).as_posix().endswith("arclet/entari/plugin/model.py"):
                    continue
                if frame.filename == self.path:
                    break
                mod_name = frame.frame.f_globals["__spec__"].name
                sys.modules.pop(mod_name, None)
                if mod_name != e.func.__module__:
                    deleted.append(mod_name)
            import_plugin(e.func.__module__)
            if deleted:
                _ensure_plugin(deleted[-1:], False, self.plugin_id, self.name)
                _ENSURE_IS_PLUGIN.update(deleted[:-1])
            try:
                code = self.get_code(module.__name__)
                if code is None:
                    raise ImportError(f"cannot load module {module.__name__r} when get_code() returns None")
                _bootstrap._call_with_frames_removed(exec, code, module.__dict__)  # type: ignore
            except Exception as e1:
                if isinstance(e1, RegisterNotInPluginError):
                    log.plugin.error(f"failed to load plugin <blue>{self.plugin_id!r}</blue>:\n{e1.msg}")
                else:
                    log.plugin.exception(
                        f"failed to load plugin <blue>{self.plugin_id!r}</blue> caused by {e!r}", exc_info=e
                    )
                plugin.dispose()
                publish(PluginLoadedFailed(self.plugin_id, e1))
                if isinstance(e, (ImportError, StaticPluginDispatchError, ReusablePluginError)):
                    raise e1 from None
                else:
                    raise ImportError(f"{e1!r} in {self.name!r}", name=self.name, path=self.path)
        except Exception as e:
            log.plugin.exception(f"failed to load plugin <blue>{self.plugin_id!r}</blue> caused by {e!r}", exc_info=e)
            plugin.dispose()
            publish(PluginLoadedFailed(self.plugin_id, e))
            if isinstance(e, (ImportError, StaticPluginDispatchError, ReusablePluginError)):
                raise
            else:
                raise ImportError(f"{e!r} in {self.name!r}", name=self.name, path=self.path)
        finally:
            # leave plugin context
            delattr(module, "__cached__")
            if not plugin.is_static or "token1" in locals():
                scope_ctx.reset(token1)  # type: ignore
            current_plugin.reset(token)

        # get plugin metadata
        metadata: PluginMetadata | None = getattr(module, "__plugin_metadata__", None)
        if metadata and not plugin.metadata:
            plugin.metadata = metadata
        plugin._apply = getattr(module, "__plugin_apply__", None)
        plugin._inspect = self._inspect
        plugin.restore_kept_state()
        del self._inspect
        staged = "staged " if self.staged else ""
        if not is_sub:
            if plugin._apply:
                log.plugin.success(f"{staged}loaded plugin <blue>{self.plugin_id!r}</blue> partially applied")
            else:
                log.plugin.success(f"{staged}loaded plugin <blue>{self.plugin_id!r}</blue>")
        else:
            log.plugin.trace(f"{staged}loaded sub-plugin <r>{plugin.id!r}</r> of <y>{self.parent_plugin_id!r}</y>")
        if not plugin._apply:
            publish(PluginLoadedSuccess(self.plugin_id))
        if plugin_service.status.blocking and not self.staged:
            if plugin._apply:
                plugin.exec_apply()
            plugin.check_disable()
            publish(Ready(), plugin._scope)
        return


class _NamespacePath(_bootstrap_external._NamespacePath):  # type: ignore
    def _get_parent_path(self):
        parent_module_name, path_attr_name = self._find_parent_path_names()
        if parent_module_name in plugin_service.plugins:
            return plugin_service.plugins[parent_module_name].module.__path__
        return getattr(sys.modules[parent_module_name], path_attr_name)


def _path_find_spec(fullname, path=None, target=None) -> ModuleSpec | None:
    """Try to find a spec for 'fullname' on sys.path or 'path'.

    The search is based on sys.path_hooks and sys.path_importer_cache.
    """
    if path is None:
        path = sys.path
    spec: ModuleSpec | None = PathFinder._get_spec(fullname, path, target)  # type: ignore
    if spec is None:
        return None
    elif spec.loader is None:
        namespace_path = spec.submodule_search_locations
        if namespace_path:
            # We found at least one namespace path.  Return a spec which
            # can create the namespace package.
            spec.origin = None
            spec.submodule_search_locations = _NamespacePath(fullname, namespace_path, PathFinder._get_spec)  # type: ignore
            return spec
        else:
            return None
    else:
        return spec


def _as_plugin(
    module_spec: ModuleSpec, fullname: str, module_origin: str, plugin_id: str, staged: bool = False
) -> ModuleSpec:
    loader = PluginLoader(fullname, module_origin, plugin_id)
    loader.staged = staged
    module_spec.loader = loader
    return module_spec


def _as_submodule(
    module_spec: ModuleSpec, fullname: str, module_origin: str, plugin_id: str, parent: str, staged: bool = False
) -> ModuleSpec:
    loader = PluginLoader(fullname, module_origin, plugin_id, parent)
    loader.staged = staged
    module_spec.loader = loader
    return module_spec


def _check_reusable(name: str, plugin_id: str) -> None:
    if any(k.startswith(name) and k.rfind("@") != -1 for k in plugin_service.plugins) and plugin_id.rfind("@") == -1:
        raise ReusablePluginError(f"reusable plugin {name!r} cannot be imported directly")


class _PluginFinder(PathFinder):
    @classmethod
    def find_spec(
        cls,
        fullname: str,
        path: Sequence[str] | None = None,
        target: ModuleType | None = None,
        origin_id_: str | None = None,
        force: bool = False,
        staged: bool = False,
    ) -> ModuleSpec | None:
        # get the module spec using the default path-finder
        module_spec = _path_find_spec(fullname, path, target)
        if not module_spec:
            return
        module_origin = module_spec.origin
        plugin_id = origin_id_ or fullname
        # if the module has no origin, it might be a namespace package or a built-in module.
        # We only care about namespace packages here, as built-in modules should not be treated as plugins.
        # For namespace packages, we can still return the spec without modification,
        # as they will be handled by the _NamespacePath class.
        if not module_origin:
            if not module_spec.loader:  # namespace package
                return module_spec
            return
        # if the module is an extension module, we should not treat it as a plugin,
        # as it cannot be reloaded and does not have a source file to analyze for plugin markers.
        if isinstance(module_spec.loader, ExtensionFileLoader):
            return
        # current import statement is within a plugin.
        if plug := current_plugin.get(None):
            # only record outside import, as inside import are already recorded by the plugin's loader.
            if module_spec.name != plug.module.__name__ and not module_spec.name.startswith(plug.module.__name__ + "."):
                _record_binding(plug.id, module_spec.name.split(".")[0], module_spec.name, None)
            # if the module being imported is the same as the plugin's module,
            # return the plugin's module spec directly to avoid infinite recursion.
            if plug.module.__spec__ and plug.module.__spec__.origin == module_origin:
                return plug.module.__spec__
            # get the top-level plugin id (the parent) of the current plugin
            parent_id = plug.id
            while parent_id in plugin_service._subplugined:
                parent_id = plugin_service._subplugined[parent_id]
            # if the module being imported is a submodule of the top-level plugin,
            # or if the module being imported is in the waitlist of the top-level plugin,
            # it means it is marked as a submodule by the plugin author.
            if module_spec.name.startswith(
                plugin_service.plugins[parent_id].module.__name__ + "."
            ) or module_spec.name in _SUBMODULE_WAITLIST.get(  # noqa: E501
                parent_id, ()
            ):
                return _as_submodule(
                    module_spec,
                    fullname,
                    module_origin,
                    plugin_id,
                    parent_id,
                    staged=staged or plug.id in plugin_service._staged,
                )  # noqa: E501
        # in the following cases, the module is imported directly (probably from Entari App)
        # 1. the module is already a plugin.
        if module_spec.name in plugin_service.plugins:
            if module_spec.name in plugin_service._subplugined:
                return _as_submodule(
                    module_spec,
                    fullname,
                    module_origin,
                    plugin_id,
                    plugin_service._subplugined[module_spec.name],
                    staged=staged,
                )  # noqa: E501
            return _as_plugin(module_spec, fullname, module_origin, plugin_id, staged=staged)
        # 2. the module is marked as a plugin by the plugin author, or followed the naming convention for plugins.
        marked = (
            module_spec.name in _ENSURE_IS_PLUGIN
            or module_spec.name.startswith("arclet.entari.builtins.")
            or module_spec.name.startswith("entari_plugin")
        )
        if not marked and EntariConfig._inited and EntariConfig.instance.basic.check_metadata:
            # if the module is installed in the environment, we can check its metadata for plugin markers.
            dist: Distribution | None = None
            try:
                dist = distribution(module_spec.name)
            except PackageNotFoundError:
                if module_spec.origin and module_spec.origin != "built-in":
                    for dist in distributions():
                        relative_path = Path(module_spec.origin).relative_to(str(dist.locate_file(""))).as_posix()
                        if relative_path in map(str, dist.files or []):
                            break
            if dist:
                try:
                    if dist.entry_points.select(group="entari.plugin"):
                        marked = True
                    classifiers = dist.metadata.get_all("Classifier", [])
                    if any(classifier in classifiers for classifier in PLUGIN_CLASSIFIERS):
                        marked = True
                    keywords = re.split(r"\s+", dist.metadata["Keywords"])
                    if any(keyword in keywords for keyword in PLUGIN_KEYWORDS):
                        marked = True
                except (KeyError, ValueError):
                    pass
        if marked:
            _as_plugin(module_spec, fullname, module_origin, plugin_id, staged=staged)
            # if there already exists a plugin that is importing this module,
            # we should add the plugin as a referent of this module
            if plug:
                plugin_service.referents.setdefault(module_spec.name, set()).add(plug.id)
            return module_spec
        # 3. the module is marked as a submodule by other plugin, or it is a submodule of a plugin.
        if module_spec.name in plugin_service._subplugined:
            return _as_submodule(
                module_spec,
                fullname,
                module_origin,
                plugin_id,
                plugin_service._subplugined[module_spec.name],
                staged=staged,
            )  # noqa: E501
        # 4. if the module is already a plugin, but it is assigned an unique id (usage of reusable plugin),
        # it cannot be imported directly, otherwise it will break the uniqueness of the plugin instance.
        _check_reusable(module_spec.name, plugin_id)
        # 5. the module is a submodule of a plugin, but it is not marked as a submodule by the plugin author,
        # we should still treat it as a submodule of the plugin to avoid breaking existing plugins.
        # notice: cannot merge two conditions below, because some spec with submodule_search_locations (Namespace),
        # their parent is the spec itself, not the parent module name.
        if module_spec.parent and module_spec.parent in plugin_service.plugins:
            return _as_submodule(module_spec, fullname, module_origin, plugin_id, module_spec.parent, staged=staged)
        if (parent_name := module_spec.name.rpartition(".")[0]) and parent_name in plugin_service.plugins:
            return _as_submodule(module_spec, fullname, module_origin, plugin_id, parent_name, staged=staged)
        # 6. force-wrap as a plugin when explicitly requested by import_plugin.
        if force:
            return _as_plugin(module_spec, fullname, module_origin, plugin_id, staged=staged)
        return


def import_plugin(id_, package=None, config: dict | None = None, staged: bool = False) -> ModuleType | None:
    uid_index = id_.rfind("@")
    name = id_ if uid_index == -1 else id_[:uid_index]
    fullname = resolve_name(name, package) if name.startswith(".") else name
    parent_name = fullname.rpartition(".")[0]
    if parent_name:
        parent: ModuleType | None
        parts = parent_name.split(".")
        _current = parts[0]
        if _current in plugin_service.plugins:
            parent = plugin_service.plugins[_current].module
            enter_plugin = True
        else:
            parent = __import__(_current, fromlist=["__path__"])
            enter_plugin = False
        _current += "."
        for part in parts[1:]:
            _current += part
            if _current in plugin_service.plugins:
                parent = plugin_service.plugins[_current].module
                enter_plugin = True
            elif _current in _ENSURE_IS_PLUGIN or enter_plugin:
                if parent := import_plugin(_current):
                    enter_plugin = True
                else:
                    parent = __import__(_current, fromlist=["__path__"])
                    enter_plugin = False
            else:
                parent = __import__(_current, fromlist=["__path__"])
            _current += "."
        if parent is None:
            raise ModuleNotFoundError(
                f"parent module {parent_name!r} does not have __path__ attribute " f"while trying to find {fullname!r}",
                name=fullname,
            )
        parent_path = parent.__path__
    else:
        parent_path = None
    spec = _PluginFinder.find_spec(fullname, parent_path, origin_id_=id_, force=True, staged=staged)
    if not spec:
        return
    mod = module_from_spec(spec)
    spec._initializing = True  # type: ignore
    try:
        if spec.loader is None:
            if spec.submodule_search_locations is None:
                raise ImportError("missing loader", name=spec.name)
            # A namespace package so do nothing.
        else:
            if isinstance(spec.loader, PluginLoader):
                spec.loader.exec_module(mod, config=config)
                protected_modules = set()
                module_name = mod.__name__
                if module_name:
                    prefix = []
                    for part in module_name.split("."):
                        prefix.append(part)
                        protected_modules.add(".".join(prefix))
                sys.modules.pop(module_name, None)
                for _imported in _IMPORTING:
                    if _imported in protected_modules or _imported in plugin_service.plugins:
                        continue
                    sys.modules.pop(_imported, None)
                _IMPORTING.clear()
            else:
                spec.loader.exec_module(mod)
                sys.modules[mod.__name__] = mod
    finally:
        spec._initializing = False  # type: ignore
    return mod


sys.meta_path.insert(0, _PluginFinder())
