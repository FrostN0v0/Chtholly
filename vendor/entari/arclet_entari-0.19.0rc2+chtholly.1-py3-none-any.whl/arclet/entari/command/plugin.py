from __future__ import annotations

import asyncio
from typing import Any
from typing_extensions import TypeVar, deprecated

from arclet.alconna import Alconna, command_manager
from arclet.letoderea import EVENT, RESULT, Contexts, Result, Subscriber, define, deref, use
from arclet.letoderea.exceptions import _ExitException
from arclet.letoderea.provider import TProviders
from arclet.letoderea.scope import SubscriberSlot
from tarina import LRU

from ..event.base import MessageCreatedEvent
from ..event.command import CommandExecute, CommandOutput
from ..message import MessageChain
from ..plugin.model import Plugin, PluginDispatcher
from ..session import Session
from .model import Match, Query
from .provider import AlconnaProviderFactory, AlconnaSuppiler, Assign, MessageJudges, _seminal

exec_pub = define(CommandExecute)
exec_provider = CommandExecute.providers[0]
exec_pub.providers.append(AlconnaProviderFactory())
out_pub = define(CommandOutput)
# fmt: off

T = TypeVar("T", default=Any)


async def _after_execute(ctx: Contexts, session: Session | None = None):
    result: str | MessageChain | _ExitException | None = ctx[RESULT]
    event = ctx[EVENT]
    if result is not None:
        if isinstance(result, _ExitException):
            if result.args:
                msg = result.args[0]
                if not isinstance(event, CommandExecute) and session:
                    await session.send(msg)
            return result
        if not isinstance(event, CommandExecute) and session:
            await session.send(result)
        return Result(result)


class _ExecuteDispatcher(PluginDispatcher[str | MessageChain]):
    def __init__(self, plugin: Plugin, supplier: AlconnaSuppiler):
        super().__init__(plugin, CommandExecute)
        plugin.collect(self.propagators.append(supplier))

    def assign(self, path: str, value: Any = _seminal, or_not: bool = False, priority: int = 16, providers: TProviders | None = None):  # noqa: E501
        assign = Assign(path, value, or_not)
        return self.register(priority=priority, providers=providers, propagators=[assign])


class AlconnaPluginDispatcher(PluginDispatcher[T]):
    def __init__(self, plugin: Plugin, command: Alconna, need_reply_me: bool = False, need_notice_me: bool = False, use_config_prefix: bool = True, block: bool = True, skip_for_unmatch: bool = True):  # noqa: E501
        plugin._extra.setdefault("commands", []).append((command.prefixes, command.command))
        self.cache: "LRU[str, asyncio.Future]" = LRU(10)  # noqa: UP037
        self.supplier = AlconnaSuppiler(command, self.cache, block, skip_for_unmatch)
        super().__init__(plugin, MessageCreatedEvent, command.path)
        plugin.collect(
            self.propagators.append(
                MessageJudges(need_reply_me, need_notice_me, use_config_prefix, None),
            ),
            self.propagators.append(self.supplier),
            self.providers.append(AlconnaProviderFactory())
        )

        @plugin.collect
        def dispose():
            _cmd = self.supplier.cmd
            # if returned, it means the subscriber is already staged reload.
            try:
                record = command_manager._resolve(_cmd._hash)
            except KeyError:
                pass
            else:
                if id(_cmd) == id(record):
                    command_manager.delete(_cmd)
            del self.supplier.cmd
            del self.supplier

    def assign(self, path: str, value: Any = _seminal, or_not: bool = False, priority: int = 16, providers: TProviders | None = None, label: str | None = None):  # noqa: E501
        assign = Assign(path, value, or_not)
        if label is None:
            label = f"{self.supplier.cmd.command}.{path}"
        return self.register(priority=priority, providers=providers, propagators=[assign], label=label)

    def as_execute(self) -> AlconnaPluginDispatcher[str | MessageChain]:
        def execute_hook(sub: Subscriber):
            self.plugin._scope.subscribers.append(
                SubscriberSlot(sub, exec_pub.id, sub.priority)
            )
            sub._recompile([exec_provider])
            sub.propagate(_after_execute)

        self.plugin.collect(self.register_hooks.append(execute_hook))
        return self  # type: ignore[return-value]

    def for_execute(self):
        return _ExecuteDispatcher(self.plugin, self.supplier)

    @deprecated("`on_execute` is deprecated. Use `as_execute` instead.")
    def on_execute(self, priority: int = 16, providers: TProviders | None = None):
        with self.plugin._scope.context():
            return use(exec_pub, priority=priority, providers=providers, propagators=[self.supplier])

    def on_output(self, priority: int = 16, providers: TProviders | None = None):
        with self.plugin._scope.context():
            return use(out_pub, priority=priority, providers=providers, propagators=[self.supplier]).if_(deref(Alconna) == self.supplier.cmd)  # noqa: E501

    Match = Match
    Query = Query


def mount(cmd: Alconna, need_reply_me: bool = False, need_notice_me: bool = False, use_config_prefix: bool = True, block: bool = True, skip_for_unmatch: bool = True) -> AlconnaPluginDispatcher:  # noqa: E501
    if not (plugin := Plugin.current()):
        raise LookupError("no plugin context found")
    return AlconnaPluginDispatcher(plugin, cmd, need_reply_me, need_notice_me, use_config_prefix, block, skip_for_unmatch)  # noqa: E501

# fmt: on
