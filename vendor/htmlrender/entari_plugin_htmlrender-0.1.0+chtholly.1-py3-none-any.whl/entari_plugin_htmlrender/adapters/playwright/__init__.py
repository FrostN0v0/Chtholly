"""Playwright provider adapter."""
